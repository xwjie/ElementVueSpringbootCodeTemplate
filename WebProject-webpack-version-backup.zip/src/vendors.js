import Vue from 'vue';
import VueRouter from 'vue-router';
import axios from 'axios';
import Vuex from 'vuex';
import echarts from 'echarts';
//import Cookies from 'js-cookie';
//import html2canvas from 'html2canvas';
//import rasterizehtml from 'rasterizehtml';